/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.aplikasikasirtoko;

/**
 *
 * @author SEKAR
 */

public class ProdukTokoo {
   
    private String namaBarang;
    private double harga;

    
    public ProdukTokoo(String namaBarang, double harga) {
        this.namaBarang = namaBarang;
        setHarga(harga); 
    }

    
    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    
    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        if (harga >= 0) {
            this.harga = harga;
        } else {
            System.out.println("Harga tidak boleh negatif!");
        }
    }
}
