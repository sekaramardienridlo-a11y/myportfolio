package com.company.aplikasikasirtoko;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SEKAR
 */



class Transaksi {
    protected ProdukTokoo produk;
    protected int jumlahBeli;

    public Transaksi(ProdukTokoo produk, int jumlahBeli) {
        this.produk = produk;
        this.jumlahBeli = jumlahBeli;
    }

    public double hitungTotalAwal() {
        return produk.getHarga() * jumlahBeli;
    }
}


class TransaksiMember extends Transaksi {
    private double persenDiskon;

    public TransaksiMember(ProdukTokoo produk, int jumlahBeli, double persenDiskon) {
        super(produk, jumlahBeli); 
        this.persenDiskon = persenDiskon;
    }

   
    public double hitungTotalAkhir() {
        double totalAwal = hitungTotalAwal();
        double potongan = totalAwal * (persenDiskon / 100);
        return totalAwal - potongan;
    }

    public double getPersenDiskon() {
        return persenDiskon;
    }
}
