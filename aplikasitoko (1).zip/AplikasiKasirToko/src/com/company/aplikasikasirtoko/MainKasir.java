/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.aplikasikasirtoko;

/**
 *
 * @author SEKAR
 */


public class MainKasir {
    public static void main(String[] args) {
        
        ProdukTokoo produk1 = new ProdukTokoo("Buku Tulis A5", 5000);

        
        int jumlahBeli = 10;
        double diskonMember = 10.0; 

        TransaksiMember transaksi = new TransaksiMember(produk1, jumlahBeli, diskonMember);

        // 3. Menampilkan Output Perhitungan Kasir
        System.out.println("===================================");
        System.out.println("       KASIR TOKO       ");
        System.out.println("===================================");
        System.out.println("Nama Barang   : " + produk1.getNamaBarang());
        System.out.println("Harga Satuan  : Rp " + produk1.getHarga());
        System.out.println("Jumlah Beli   : " + jumlahBeli + " pcs");
        System.out.println("-----------------------------------");
        System.out.println("Total Awal    : Rp " + transaksi.hitungTotalAwal());
        System.out.println("Diskon Member : " + transaksi.getPersenDiskon() + "%");
        System.out.println("-----------------------------------");
        System.out.println("Total Bayar   : Rp " + transaksi.hitungTotalAkhir());
        System.out.println("===================================");
    }
}
